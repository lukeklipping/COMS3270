This part of the Roguelike project adds dynamic monster and object instances to the dungeon, created from parsed descriptions.
 Unique entities are limited to one instance, and objects are rendered with color using curses. Objects can persist on the floor 
 and optionally be picked up or destroyed by monsters. Press 'f' to rid of fog, and see all monsters and objects.

 for ta:
    Sometimes it throws a segfault. Just re run it again